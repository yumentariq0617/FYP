import React, { useEffect, useState } from 'react';
import { useNavigate, NavLink } from 'react-router-dom';
import Footer from '../Project/Footer';

const Home = () => {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);

  useEffect(() => {
    const storedUser = localStorage.getItem('user');
    if (!storedUser) {
      navigate('/login'); 
    } else {
      setUser(JSON.parse(storedUser));
    }
  }, [navigate]);


  const handleLogout = () => {
    localStorage.removeItem('user'); 
    navigate('/login'); 
  };


  return (
    <div>
      <nav className="navbar">
        <ul>
          <div className='navlogo'>
            <img src="vg.png" alt="Logo" />
          </div>
          <li className="navlink"><NavLink to={'#home'}>Home</NavLink></li>
          <li className="navlink"><NavLink to={'#about'}>About</NavLink></li>
          {user && <NavLink to={'/user-profile'}> <li className="navlink">{user.name}</li></NavLink>}
          <li className="logout" onClick={handleLogout}><NavLink to={'/login'}>Log Out</NavLink></li>
        </ul>
      </nav>
      <div className="Homemaindiv">
        <div className="corner">
          <div><img src="vg.png" alt="Vision Forge Logo" /></div>
          <label>VISION FORGE</label>
        </div>
        <div className="frontimg">
          <img src="fig.png" alt="Front" />
        </div>
      </div>
      <div className="buttons">
        <NavLink to={'/careerform'}><li className="select">Select Career</li></NavLink>
        <NavLink to={'/uform'}><li className="select">Select University</li></NavLink>
      </div>
      <Footer />
    </div>
  );
};

export default Home;
