import React , {useEffect, useState} from 'react';
import { NavLink, useLocation, useNavigate } from 'react-router-dom';
import '../App.css';
import Footer from './Footer';

const UResult = () => {
    const { state } = useLocation();
    const { result } = state;
    
    const navigate=useNavigate();
    
    const [user, setUser] = useState(null);

    useEffect(() => {
      const storedUser = localStorage.getItem('user');
      if (!storedUser) {
        navigate('/login'); 
      } else {
        setUser(JSON.parse(storedUser));
      }
    }, [navigate]);

    const handleLogout = () => {
        localStorage.removeItem('user'); 
        navigate('/login'); 
      };

    return (
        <div>
            <nav className="navbar">
                <ul>
                    <div className='navlogo'>
                        <img src="vg.png" alt="Logo" />
                    </div>
                    <NavLink to={'/home'}><li className="navlink" >Home</li></NavLink> 

                    {user && <NavLink to={'/user-profile'}> <li className="navlink">{user.name}</li></NavLink>}
                    <NavLink to={'/login'}><li className="navlink" onClick={handleLogout}>Logout</li></NavLink> 
                </ul>
            </nav>
            <div className="resultdiv">
                <div className="label">
                    <label>Your University Search is Completed</label>
                    <h4>Following is the university that is suitable for you</h4>
                </div>
                {result.university ? (
                    <div className="fields">
                        <div className="career">
                            <div className="careerimg">
                                <img src="ucp.jpeg" alt="University" />
                            </div>
                            <h4>{result.university}</h4>
                            {result.required_tests && (
                                <div>
                                    <h4><b>Required Tests</b></h4>
                                    <p>{result.required_tests}</p>
                                </div>
                            )}
                        </div>
                    </div>
                ) : (
                    <div className="fields">
                        <div className="career">
                            <div className="careerimg">
                                <img src="notfound.jpeg" alt="Not Found" />
                            </div>
                            <h4>{result.message}</h4>
                        </div>
                    </div>
                )}
            </div>
            <Footer />
        </div>
    );
};

export default UResult;
