import React, { useState, useEffect } from 'react';
import './CareerForm.css';
import { useNavigate } from 'react-router-dom';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const UForm = () => {
    const [formData, setFormData] = useState({
        interMarks: '',
        matricMarks: '',
        selectedCourse: '',
    });
    const navigate = useNavigate();
    const [submitting, setSubmitting] = useState(false);

    useEffect(() => {
        const user = localStorage.getItem('user');
        if (!user) {
            navigate('/login'); // Redirect to login if user is not logged in
        }
    }, [navigate]);

    const courses = [
        'BS Accounting',
        'Civil Engineering',
        'Mechatronics Engineering',
        'Bachelors in Computer Science',
        'LLB',
        'Bachelors in Software Engineering',
        'Doctor of Physiotherapy (DPT)',
        'Bachelors in Artificial Engineering',
        'BS Media and Communication',
        'Veterinary Sciences',
        'Bachelor of Business Administration (BBA)',
        'Aeronautical Engineering',
        'Mechanical Engineering',
        'BS English (Literature)',
        'Bachelors in IT',
        'BS Data Science', 'BS Chemistry', 'BS Mathematics', 'BS Physics',
        'B.Sc. Electrical Engineering','BS Film  TV & Digital Media', 'BS Political Science'

    ];

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData({
            ...formData,
            [name]: value,
        });
    };

    const handleSubmit = (e) => {
        e.preventDefault();

        setSubmitting(true);

        if (!formData.interMarks || !formData.matricMarks || !formData.selectedCourse) {
            toast.error('All fields are required!');
            setSubmitting(false);
            return;
        }

        const interMarks = parseFloat(formData.interMarks);
        const selectedCourse = formData.selectedCourse;

        let result = {};

        // Check for courses that require specific criteria
        if (interMarks >= 50 && ['Bachelors in Business Administration','Bachelors in IT' ,'BS Data Science','Bachelors in Computer Science','Bachelors in Software Engineering','Bachelors in Artificial Intelligence'].includes(selectedCourse)) {
            result = {
                university: 'University of Central Punjab',
                required_tests: 'UCP test / NTS test '
            };
        } else if (interMarks >= 60 && ['Civil Engineering',  'B.Sc. Electrical Engineering' ,'Mechanical Engineering', 'Electrical Engineering'].includes(selectedCourse)) {
            result = {
                university: 'University of Central Punjab',
                required_tests: 'UCP test / ECAT test / NTS test'
            };
        } else if (interMarks >= 45 && [
            'BS Accounting',
            'Chemical Engineering',
            'BDS',
            'LLB',
            'BS Media and Communication',
            'Veterinary Sciences',
            'Aeronautical Engineering',
            'BS English (Literature)',
            'BS Chemistry', 'BS Mathematics', 'BS Physics', 'BS Film  TV & Digital Media', 'BS Political Science'

            
        ].includes(selectedCourse)) {
            result = {
                university: 'University of Central Punjab',
                required_tests: 'UCP test / NTS test/ Interview / In-house Written Test'
            };
        } else {
            result = {
                message: 'Your marks/course do not meet the criteria of the course/selected university.'
            };
        }

        navigate('/uresult', { state: { result } });

        setSubmitting(false);
    };

    return (
        <div className="career-form-container">
            <h2 className="career-form-title">Search Universities</h2>
            <form className="career-form" onSubmit={handleSubmit}>
                <div className="career-form-group">
                    <label className="career-form-label" htmlFor="interMarks">Inter Marks (%)</label>
                    <input
                        type="number"
                        id="interMarks"
                        name="interMarks"
                        value={formData.interMarks}
                        onChange={handleChange}
                        className="career-form-input"
                        required
                    />
                </div>
                <div className="career-form-group">
                    <label className="career-form-label" htmlFor="matricMarks">Matric Marks (%)</label>
                    <input
                        type="number"
                        id="matricMarks"
                        name="matricMarks"
                        value={formData.matricMarks}
                        onChange={handleChange}
                        className="career-form-input"
                        required
                    />
                </div>
                <div className="career-form-group">
                    <label className="career-form-label" htmlFor="selectedCourse">Course</label>
                    <select
                        id="selectedCourse"
                        name="selectedCourse"
                        value={formData.selectedCourse}
                        onChange={handleChange}
                        className="career-form-select"
                        required
                    >
                        <option value="">Select Course</option>
                        {courses.map((course, index) => (
                            <option key={index} value={course}>
                                {course}
                            </option>
                        ))}
                    </select>
                </div>
                <button type="submit" disabled={submitting} className="career-form-submit">
                    {submitting ? 'Submitting...' : 'Submit'}
                </button>
            </form>
            <ToastContainer />
        </div>
    );
};

export default UForm;
