import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import './UserProfile.css';

const UserProfile = () => {
  const [user, setUser] = useState(JSON.parse(localStorage.getItem('user')) || {});
  const [newPassword, setNewPassword] = useState('');
  const [message, setMessage] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    if (!user || !user.email) {
      navigate('/login'); // Redirect to login if user is not logged in or user data is incomplete
    }
  }, [user, navigate]);

  const handlePasswordChange = async (e) => {
    e.preventDefault();

    try {
      const response = await axios.post('http://localhost:8080/update-password', {
        email: user.email,
        password: newPassword
      });

      if (response.data.status === 'success') {
        toast.success('Password updated successfully.');
        const updatedUser = { ...user, password: newPassword };
        setUser(updatedUser);
        localStorage.setItem('user', JSON.stringify(updatedUser));
        setTimeout(() => {
          navigate('/home');
        }, 2000);
      } else {
        setMessage(response.data.message);
        toast.error(response.data.message);
      }
    } catch (error) {
      console.error("Error updating password:", error);
      setMessage('Failed to update password. Please try again.');
      toast.error('Failed to update password. Please try again.');
    }
  };

  return (
    <div className="user-profile-container">
      <h2>User Profile</h2>
      <div className="profile-details">
        <p>Name: {user.name}</p>
        <p>Email: {user.email}</p>
        <form onSubmit={handlePasswordChange}>
          <input
            type="password"
            placeholder="New Password"
            value={newPassword}
            onChange={(e) => setNewPassword(e.target.value)}
            required
          />
          <button type="submit">Update Password</button>
        </form>
        {message && <p className="message">{message}</p>}
      </div>
      <ToastContainer position="top-center" autoClose={3000} hideProgressBar={false} newestOnTop={false} closeOnClick rtl={false} pauseOnFocusLoss draggable pauseOnHover />
    </div>
  );
};

export default UserProfile;
