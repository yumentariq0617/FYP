from flask import Flask, request, jsonify
import pandas as pd
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

# Load the Excel file once when the server starts
df = pd.read_excel('ucp_programs.xlsx')

# Helper function to extract the percentage value from the criteria
def extract_percentage(criteria):
    if isinstance(criteria, str):
        parts = criteria.split()
        for part in parts:
            if '%' in part:
                try:
                    return float(part.replace('%', ''))
                except ValueError:
                    continue
    return None

# Preprocess the dataframe to extract the percentage values
df['Admission Percentage'] = df['Admission Criteria'].apply(extract_percentage)

def check_eligibility(inter_marks, field, df):
    try:
        inter_marks = float(inter_marks)
    except ValueError:
        return "Invalid intermediate marks"

    eligible_programs = df[(df['Admission Percentage'] <= inter_marks) & (df['Program Name'].str.contains(field, case=False, na=False))]
    if not eligible_programs.empty:
        program = eligible_programs.iloc[0]
        return {
            "university": "University of Central Punjab",
            "required_tests": program['Required Tests']
        }
    else:
        return "Your marks are less than the criteria in our available list of universities."

@app.route('/check-eligibility', methods=['POST'])
def check_eligibility_endpoint():
    data = request.get_json()
    inter_marks = data['interMarks']
    field = data['selectedCourse']
    
    result = check_eligibility(inter_marks, field, df)
    return jsonify(result)

if __name__ == '__main__':
    app.run(port=5001, debug=True)
